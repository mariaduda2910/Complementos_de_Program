from administrador import Administrador
from pessoa import Pessoa
from fornecedor import Fornecedor 
from empregado import Empregado
from operario import Operario
import pickle 

list_de_pessoas = []
list_de_administradores = []
list_de_fornecedores = []
list_de_empregados = []
lista_de_operarios = []

def menu():
    pass